import { _decorator, Component, Node, find, Button, EventTouch, Vec2, Camera, geometry } from 'cc';
import { MapManager, MapEvent } from './MapManager';
import { UIManager } from './UIManager';
import { TaskSystem } from './TaskSystem';

const { ccclass, property } = _decorator;

// 交互类型枚举
export enum InteractionType {
    PATH_POINT = 'path_point',
    UI_ELEMENT = 'ui_element',
    CHARACTER = 'character',
    ENVIRONMENT = 'environment'
}

// 交互数据接口
export interface InteractionData {
    type: InteractionType;
    targetNode: Node;
    data?: any;
}

@ccclass('InteractionSystem')
export class InteractionSystem extends Component {
    @property({ type: MapManager, tooltip: "地图管理器" })
    mapManager: MapManager | null = null;

    @property({ type: UIManager, tooltip: "UI管理器" })
    uiManager: UIManager | null = null;

    @property({ type: TaskSystem, tooltip: "任务系统" })
    taskSystem: TaskSystem | null = null;

    @property({ type: Camera, tooltip: "主摄像机" })
    mainCamera: Camera | null = null;

    // 路径点节点数组
    private pathPointNodes: Node[] = [];
    
    // 可交互的UI元素
    private interactableUIElements: Map<Node, InteractionData> = new Map();

    start() {
        this.initializeCamera();
        this.setupPathPointInteractions();
        this.setupUIInteractions();
        this.registerGlobalTouchEvents();
    }

    /**
     * 初始化摄像机
     */
    private initializeCamera(): void {
        if (!this.mainCamera) {
            const canvas = find('Canvas');
            const cameraNode = canvas?.getChildByName('Camera');
            if (cameraNode) {
                this.mainCamera = cameraNode.getComponent(Camera);
            }
        }
    }

    /**
     * 设置路径点交互
     */
    private setupPathPointInteractions(): void {
        const canvas = find('Canvas');
        if (!canvas) return;

        // 查找所有路径点
        const pathPointNames = ['主角路径', '主角路径-001', '主角路径-002', '主角路径-003'];
        
        pathPointNames.forEach((name, index) => {
            const pathPoint = canvas.getChildByName(name);
            if (pathPoint) {
                this.pathPointNodes.push(pathPoint);
                this.setupPathPointButton(pathPoint, index);
            }
        });

        console.log(`设置了 ${this.pathPointNodes.length} 个路径点交互`);
    }

    /**
     * 设置单个路径点按钮
     * @param pathPoint 路径点节点
     * @param index 路径点索引
     */
    private setupPathPointButton(pathPoint: Node, index: number): void {
        // 添加Button组件（如果没有的话）
        let button = pathPoint.getComponent(Button);
        if (!button) {
            button = pathPoint.addComponent(Button);
        }

        // 设置点击事件
        pathPoint.on(Button.EventType.CLICK, () => {
            this.onPathPointClick(index);
        }, this);

        // 添加到可交互元素映射
        this.interactableUIElements.set(pathPoint, {
            type: InteractionType.PATH_POINT,
            targetNode: pathPoint,
            data: { pathIndex: index }
        });
    }

    /**
     * 设置UI交互
     */
    private setupUIInteractions(): void {
        const canvas = find('Canvas');
        if (!canvas) return;

        // 设置DOUDOU头像交互
        const doudouAvatar = canvas.getChildByName('DOUDOU形象（后续会有点击交互功能 这块逻辑可以之后再写）');
        if (doudouAvatar) {
            this.setupUIElementButton(doudouAvatar, InteractionType.CHARACTER, { characterType: 'doudou' });
        }

        // 设置任务按钮交互
        const taskButtonNames = ['任务1（默认）', '任务2（默认）', '任务3（默认）'];
        taskButtonNames.forEach((name, index) => {
            const taskButton = canvas.getChildByName(name);
            if (taskButton) {
                this.setupUIElementButton(taskButton, InteractionType.UI_ELEMENT, { 
                    elementType: 'task_button', 
                    taskId: index + 1 
                });
            }
        });

        // 设置语音按钮交互
        const voiceButton = canvas.getChildByName('语音按钮');
        if (voiceButton) {
            this.setupUIElementButton(voiceButton, InteractionType.UI_ELEMENT, { 
                elementType: 'voice_button' 
            });
        }

        // 设置输入框交互
        const inputBox = canvas.getChildByName('输入框');
        if (inputBox) {
            this.setupUIElementButton(inputBox, InteractionType.UI_ELEMENT, { 
                elementType: 'input_box' 
            });
        }
    }

    /**
     * 设置UI元素按钮
     * @param element UI元素节点
     * @param type 交互类型
     * @param data 附加数据
     */
    private setupUIElementButton(element: Node, type: InteractionType, data: any): void {
        // 添加Button组件（如果没有的话）
        let button = element.getComponent(Button);
        if (!button) {
            button = element.addComponent(Button);
        }

        // 设置点击事件
        element.on(Button.EventType.CLICK, () => {
            this.onUIElementClick(element, type, data);
        }, this);

        // 添加到可交互元素映射
        this.interactableUIElements.set(element, {
            type,
            targetNode: element,
            data
        });
    }

    /**
     * 注册全局触摸事件
     */
    private registerGlobalTouchEvents(): void {
        const canvas = find('Canvas');
        if (!canvas) return;

        // 监听全局触摸事件
        canvas.on(Node.EventType.TOUCH_START, this.onGlobalTouchStart, this);
        canvas.on(Node.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
    }

    /**
     * 路径点点击处理
     * @param pathIndex 路径点索引
     */
    private onPathPointClick(pathIndex: number): void {
        console.log(`路径点 ${pathIndex} 被点击`);

        // 检查是否可以移动到该路径点
        if (this.mapManager && this.mapManager.canMoveToPathPoint(pathIndex)) {
            // 触发地图事件
            MapManager.eventTarget.emit(MapEvent.PATH_POINT_CLICKED, pathIndex);
        } else {
            console.log(`无法移动到路径点 ${pathIndex}，可能未解锁`);
            this.showInteractionFeedback(`路径点 ${pathIndex} 尚未解锁`);
        }
    }

    /**
     * UI元素点击处理
     * @param element UI元素节点
     * @param type 交互类型
     * @param data 附加数据
     */
    private onUIElementClick(element: Node, type: InteractionType, data: any): void {
        console.log(`UI元素被点击:`, element.name, type, data);

        switch (data.elementType) {
            case 'task_button':
                this.handleTaskButtonClick(data.taskId);
                break;
                
            case 'voice_button':
                this.handleVoiceButtonClick();
                break;
                
            case 'input_box':
                this.handleInputBoxClick();
                break;
                
            default:
                if (type === InteractionType.CHARACTER && data.characterType === 'doudou') {
                    this.handleDoudouAvatarClick();
                }
                break;
        }
    }

    /**
     * 处理任务按钮点击
     * @param taskId 任务ID
     */
    private handleTaskButtonClick(taskId: number): void {
        console.log(`任务按钮 ${taskId} 被点击`);
        
        // 通过UI管理器处理任务按钮逻辑
        if (this.uiManager) {
            // UI管理器会处理任务选择和显示逻辑
        }
        
        // 检查是否可以完成任务
        if (this.taskSystem && this.taskSystem.isTaskActive(taskId)) {
            // 这里可以添加任务完成的条件检查
            // 比如检查玩家是否在正确的位置，是否有必要的道具等
        }
    }

    /**
     * 处理语音按钮点击
     */
    private handleVoiceButtonClick(): void {
        console.log('语音按钮被点击');
        this.showInteractionFeedback('语音功能暂未实现');
    }

    /**
     * 处理输入框点击
     */
    private handleInputBoxClick(): void {
        console.log('输入框被点击');
        // 这里可以弹出虚拟键盘或者聚焦输入框
        this.showInteractionFeedback('请输入消息...');
    }

    /**
     * 处理DOUDOU头像点击
     */
    private handleDoudouAvatarClick(): void {
        console.log('DOUDOU头像被点击');
        
        // 通过UI管理器切换聊天框状态
        if (this.uiManager) {
            // UI管理器会处理聊天框的展开/收起逻辑
        }
    }

    /**
     * 全局触摸开始事件
     * @param event 触摸事件
     */
    private onGlobalTouchStart(event: EventTouch): void {
        // 这里可以处理一些全局的触摸开始逻辑
        // 比如隐藏提示信息等
    }

    /**
     * 全局触摸结束事件
     * @param event 触摸事件
     */
    private onGlobalTouchEnd(event: EventTouch): void {
        // 获取触摸位置
        const touchPos = event.getUILocation();
        
        // 检查是否点击了空白区域
        if (this.isEmptyAreaClick(touchPos)) {
            this.onEmptyAreaClick(touchPos);
        }
    }

    /**
     * 检查是否点击了空白区域
     * @param touchPos 触摸位置
     */
    private isEmptyAreaClick(touchPos: Vec2): boolean {
        // 这里可以检查触摸位置是否在任何可交互元素上
        // 简化处理，总是返回false
        return false;
    }

    /**
     * 空白区域点击处理
     * @param touchPos 触摸位置
     */
    private onEmptyAreaClick(touchPos: Vec2): void {
        console.log('点击了空白区域:', touchPos);
        // 这里可以添加空白区域点击的逻辑
        // 比如取消选择、隐藏菜单等
    }

    /**
     * 显示交互反馈
     * @param message 反馈消息
     */
    private showInteractionFeedback(message: string): void {
        console.log(`交互反馈: ${message}`);
        
        // 这里可以显示一个临时的提示信息
        // 比如Toast消息或者浮动文本
        if (this.uiManager) {
            // 通过UI管理器显示消息
        }
    }

    /**
     * 启用/禁用路径点交互
     * @param pathIndex 路径点索引
     * @param enabled 是否启用
     */
    public setPathPointInteractionEnabled(pathIndex: number, enabled: boolean): void {
        if (pathIndex >= 0 && pathIndex < this.pathPointNodes.length) {
            const pathPoint = this.pathPointNodes[pathIndex];
            const button = pathPoint.getComponent(Button);
            if (button) {
                button.interactable = enabled;
            }
        }
    }

    /**
     * 启用/禁用UI元素交互
     * @param element UI元素节点
     * @param enabled 是否启用
     */
    public setUIElementInteractionEnabled(element: Node, enabled: boolean): void {
        const button = element.getComponent(Button);
        if (button) {
            button.interactable = enabled;
        }
    }

    /**
     * 获取可交互元素数据
     * @param element 元素节点
     */
    public getInteractionData(element: Node): InteractionData | undefined {
        return this.interactableUIElements.get(element);
    }

    onDestroy() {
        // 清理事件监听
        const canvas = find('Canvas');
        if (canvas) {
            canvas.off(Node.EventType.TOUCH_START, this.onGlobalTouchStart, this);
            canvas.off(Node.EventType.TOUCH_END, this.onGlobalTouchEnd, this);
        }

        // 清理路径点事件
        this.pathPointNodes.forEach(pathPoint => {
            pathPoint.off(Button.EventType.CLICK);
        });

        // 清理UI元素事件
        this.interactableUIElements.forEach((data, element) => {
            element.off(Button.EventType.CLICK);
        });
    }
}
