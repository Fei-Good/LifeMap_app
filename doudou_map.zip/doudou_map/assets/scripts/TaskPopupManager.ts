import { _decorator, Component, Node, find, Button, Label, Sprite, SpriteFrame, tween, Vec3, UIOpacity, BlockInputEvents } from 'cc';
import { TaskSystem, TaskConfig } from './TaskSystem';
import { UIManager } from './UIManager';

const { ccclass, property } = _decorator;

// 弹窗结果枚举
export enum PopupResult {
    COMPLETE = 'complete',
    ABANDON = 'abandon',
    CANCEL = 'cancel'
}

@ccclass('TaskPopupManager')
export class TaskPopupManager extends Component {
    @property({ type: Node, tooltip: "弹窗根节点" })
    popupRoot: Node | null = null;

    @property({ type: Node, tooltip: "弹窗背景遮罩" })
    popupMask: Node | null = null;

    @property({ type: Node, tooltip: "弹窗内容面板" })
    popupPanel: Node | null = null;

    @property({ type: Label, tooltip: "任务标题" })
    taskTitle: Label | null = null;

    @property({ type: Label, tooltip: "任务描述" })
    taskDescription: Label | null = null;

    @property({ type: Label, tooltip: "任务奖励" })
    taskRewards: Label | null = null;

    @property({ type: Button, tooltip: "完成按钮" })
    completeButton: Button | null = null;

    @property({ type: Button, tooltip: "放弃按钮" })
    abandonButton: Button | null = null;

    @property({ type: Button, tooltip: "取消按钮" })
    cancelButton: Button | null = null;

    @property({ type: Sprite, tooltip: "任务图标" })
    taskIcon: Sprite | null = null;

    // 当前显示的任务
    private currentTask: TaskConfig | null = null;
    
    // 回调函数
    private onResultCallback: ((result: PopupResult, taskId: number) => void) | null = null;

    // 系统引用
    private taskSystem: TaskSystem | null = null;
    private uiManager: UIManager | null = null;

    start() {
        this.initializeComponents();
        this.setupEventListeners();
        this.hidePopup(false); // 初始状态隐藏弹窗
    }

    /**
     * 初始化组件引用
     */
    private initializeComponents(): void {
        const canvas = find('Canvas');
        if (!canvas) return;

        // 如果没有手动设置，尝试自动查找组件
        if (!this.popupRoot) {
            this.popupRoot = this.node;
        }

        // 查找子组件
        if (this.popupRoot) {
            if (!this.popupMask) {
                this.popupMask = this.popupRoot.getChildByName('PopupMask');
            }
            
            if (!this.popupPanel) {
                this.popupPanel = this.popupRoot.getChildByName('PopupPanel');
            }

            if (this.popupPanel) {
                // 查找面板内的组件
                if (!this.taskTitle) {
                    const titleNode = this.popupPanel.getChildByName('TaskTitle');
                    this.taskTitle = titleNode?.getComponent(Label) || null;
                }

                if (!this.taskDescription) {
                    const descNode = this.popupPanel.getChildByName('TaskDescription');
                    this.taskDescription = descNode?.getComponent(Label) || null;
                }

                if (!this.taskRewards) {
                    const rewardsNode = this.popupPanel.getChildByName('TaskRewards');
                    this.taskRewards = rewardsNode?.getComponent(Label) || null;
                }

                if (!this.taskIcon) {
                    const iconNode = this.popupPanel.getChildByName('TaskIcon');
                    this.taskIcon = iconNode?.getComponent(Sprite) || null;
                }

                // 查找按钮
                if (!this.completeButton) {
                    const completeNode = this.popupPanel.getChildByName('CompleteButton');
                    this.completeButton = completeNode?.getComponent(Button) || null;
                }

                if (!this.abandonButton) {
                    const abandonNode = this.popupPanel.getChildByName('AbandonButton');
                    this.abandonButton = abandonNode?.getComponent(Button) || null;
                }

                if (!this.cancelButton) {
                    const cancelNode = this.popupPanel.getChildByName('CancelButton');
                    this.cancelButton = cancelNode?.getComponent(Button) || null;
                }
            }
        }

        // 获取系统引用
        const gameManager = canvas.getChildByName('GameManager');
        if (gameManager) {
            this.taskSystem = gameManager.getComponent(TaskSystem);
            this.uiManager = gameManager.getComponent(UIManager);
        }

        console.log('TaskPopupManager 组件初始化完成');
    }

    /**
     * 设置事件监听
     */
    private setupEventListeners(): void {
        // 完成按钮
        if (this.completeButton) {
            this.completeButton.node.on(Button.EventType.CLICK, () => {
                this.onButtonClick(PopupResult.COMPLETE);
            }, this);
        }

        // 放弃按钮
        if (this.abandonButton) {
            this.abandonButton.node.on(Button.EventType.CLICK, () => {
                this.onButtonClick(PopupResult.ABANDON);
            }, this);
        }

        // 取消按钮
        if (this.cancelButton) {
            this.cancelButton.node.on(Button.EventType.CLICK, () => {
                this.onButtonClick(PopupResult.CANCEL);
            }, this);
        }

        // 点击遮罩关闭弹窗
        if (this.popupMask) {
            this.popupMask.on(Button.EventType.CLICK, () => {
                this.onButtonClick(PopupResult.CANCEL);
            }, this);
        }
    }

    /**
     * 显示任务弹窗
     * @param taskConfig 任务配置
     * @param callback 结果回调
     */
    public showTaskPopup(taskConfig: TaskConfig, callback?: (result: PopupResult, taskId: number) => void): void {
        this.currentTask = taskConfig;
        this.onResultCallback = callback || null;

        // 更新弹窗内容
        this.updatePopupContent(taskConfig);

        // 显示弹窗
        this.showPopup();

        console.log(`显示任务弹窗: ${taskConfig.title}`);
    }

    /**
     * 更新弹窗内容
     * @param taskConfig 任务配置
     */
    private updatePopupContent(taskConfig: TaskConfig): void {
        // 更新标题
        if (this.taskTitle) {
            this.taskTitle.string = taskConfig.title;
        }

        // 更新描述
        if (this.taskDescription) {
            this.taskDescription.string = taskConfig.description;
        }

        // 更新奖励信息
        if (this.taskRewards) {
            const rewardsText = taskConfig.rewards.join('\n');
            this.taskRewards.string = `奖励:\n${rewardsText}`;
        }

        // 更新任务图标（根据任务类型）
        if (this.taskIcon) {
            this.updateTaskIcon(taskConfig.type);
        }

        // 根据任务状态更新按钮状态
        this.updateButtonStates(taskConfig);
    }

    /**
     * 更新任务图标
     * @param taskType 任务类型
     */
    private updateTaskIcon(taskType: number): void {
        if (!this.taskIcon) return;

        // 这里可以根据任务类型设置不同的图标
        // 暂时使用颜色来区分不同类型
        switch (taskType) {
            case 1: // 移动类任务
                this.taskIcon.color = new cc.Color(0, 255, 0, 255); // 绿色
                break;
            case 2: // 交互类任务
                this.taskIcon.color = new cc.Color(0, 0, 255, 255); // 蓝色
                break;
            case 3: // 收集类任务
                this.taskIcon.color = new cc.Color(255, 255, 0, 255); // 黄色
                break;
            default:
                this.taskIcon.color = new cc.Color(255, 255, 255, 255); // 白色
                break;
        }
    }

    /**
     * 更新按钮状态
     * @param taskConfig 任务配置
     */
    private updateButtonStates(taskConfig: TaskConfig): void {
        // 检查任务是否可以完成
        const canComplete = this.canCompleteTask(taskConfig);
        
        if (this.completeButton) {
            this.completeButton.interactable = canComplete;
            // 可以在这里更新按钮外观
        }

        // 放弃按钮通常总是可用的
        if (this.abandonButton) {
            this.abandonButton.interactable = true;
        }
    }

    /**
     * 检查任务是否可以完成
     * @param taskConfig 任务配置
     */
    private canCompleteTask(taskConfig: TaskConfig): boolean {
        // 这里可以添加任务完成条件的检查逻辑
        // 比如检查玩家是否在正确位置，是否有必要道具等
        
        if (this.taskSystem) {
            return this.taskSystem.isTaskActive(taskConfig.id);
        }
        
        return true; // 默认可以完成
    }

    /**
     * 按钮点击处理
     * @param result 点击结果
     */
    private onButtonClick(result: PopupResult): void {
        if (!this.currentTask) return;

        const taskId = this.currentTask.id;
        
        console.log(`任务弹窗按钮点击: ${result}, 任务ID: ${taskId}`);

        // 执行对应操作
        switch (result) {
            case PopupResult.COMPLETE:
                this.handleTaskComplete(taskId);
                break;
                
            case PopupResult.ABANDON:
                this.handleTaskAbandon(taskId);
                break;
                
            case PopupResult.CANCEL:
                // 只是关闭弹窗，不做其他操作
                break;
        }

        // 调用回调函数
        if (this.onResultCallback) {
            this.onResultCallback(result, taskId);
        }

        // 隐藏弹窗
        this.hidePopup();
    }

    /**
     * 处理任务完成
     * @param taskId 任务ID
     */
    private handleTaskComplete(taskId: number): void {
        if (this.taskSystem) {
            this.taskSystem.completeTask(taskId);
            console.log(`任务 ${taskId} 已完成`);
        }
    }

    /**
     * 处理任务放弃
     * @param taskId 任务ID
     */
    private handleTaskAbandon(taskId: number): void {
        // 这里可以添加放弃任务的逻辑
        // 比如重置任务状态、扣除一些资源等
        console.log(`任务 ${taskId} 已放弃`);
        
        // 可以通过事件系统通知其他组件
        // TaskSystem.eventTarget.emit('task_abandoned', taskId);
    }

    /**
     * 显示弹窗动画
     */
    private showPopup(): void {
        if (!this.popupRoot) return;

        // 显示弹窗根节点
        this.popupRoot.active = true;

        // 重置状态
        if (this.popupPanel) {
            this.popupPanel.setScale(0.5, 0.5, 1);
            const opacity = this.popupPanel.getComponent(UIOpacity);
            if (opacity) {
                opacity.opacity = 0;
            }
        }

        if (this.popupMask) {
            const maskOpacity = this.popupMask.getComponent(UIOpacity);
            if (maskOpacity) {
                maskOpacity.opacity = 0;
            }
        }

        // 播放显示动画
        const duration = 0.3;

        // 遮罩淡入
        if (this.popupMask) {
            const maskOpacity = this.popupMask.getComponent(UIOpacity);
            if (maskOpacity) {
                tween(maskOpacity)
                    .to(duration, { opacity: 128 })
                    .start();
            }
        }

        // 面板缩放和淡入
        if (this.popupPanel) {
            const panelOpacity = this.popupPanel.getComponent(UIOpacity);
            
            tween(this.popupPanel)
                .to(duration, { scale: new Vec3(1, 1, 1) })
                .start();
                
            if (panelOpacity) {
                tween(panelOpacity)
                    .to(duration, { opacity: 255 })
                    .start();
            }
        }
    }

    /**
     * 隐藏弹窗动画
     * @param animated 是否播放动画
     */
    private hidePopup(animated: boolean = true): void {
        if (!this.popupRoot) return;

        if (!animated) {
            this.popupRoot.active = false;
            return;
        }

        const duration = 0.2;

        // 面板缩放和淡出
        if (this.popupPanel) {
            const panelOpacity = this.popupPanel.getComponent(UIOpacity);
            
            tween(this.popupPanel)
                .to(duration, { scale: new Vec3(0.5, 0.5, 1) })
                .start();
                
            if (panelOpacity) {
                tween(panelOpacity)
                    .to(duration, { opacity: 0 })
                    .start();
            }
        }

        // 遮罩淡出
        if (this.popupMask) {
            const maskOpacity = this.popupMask.getComponent(UIOpacity);
            if (maskOpacity) {
                tween(maskOpacity)
                    .to(duration, { opacity: 0 })
                    .call(() => {
                        // 动画完成后隐藏弹窗
                        this.popupRoot!.active = false;
                        this.currentTask = null;
                        this.onResultCallback = null;
                    })
                    .start();
            }
        } else {
            // 如果没有遮罩，延迟隐藏
            this.scheduleOnce(() => {
                this.popupRoot!.active = false;
                this.currentTask = null;
                this.onResultCallback = null;
            }, duration);
        }
    }

    /**
     * 检查弹窗是否显示中
     */
    public isPopupVisible(): boolean {
        return this.popupRoot ? this.popupRoot.active : false;
    }

    /**
     * 获取当前任务
     */
    public getCurrentTask(): TaskConfig | null {
        return this.currentTask;
    }

    onDestroy() {
        // 清理事件监听
        if (this.completeButton) {
            this.completeButton.node.off(Button.EventType.CLICK);
        }
        if (this.abandonButton) {
            this.abandonButton.node.off(Button.EventType.CLICK);
        }
        if (this.cancelButton) {
            this.cancelButton.node.off(Button.EventType.CLICK);
        }
        if (this.popupMask) {
            this.popupMask.off(Button.EventType.CLICK);
        }
    }
}
