import { _decorator, Component, Node, EventTarget } from 'cc';
import { MapManager, MapEvent } from './MapManager';
import { UIManager, TaskData, TaskState } from './UIManager';

const { ccclass, property } = _decorator;

// 任务系统事件
export enum TaskEvent {
    TASK_STARTED = 'task_started',
    TASK_COMPLETED = 'task_completed',
    TASK_FAILED = 'task_failed',
    ALL_TASKS_COMPLETED = 'all_tasks_completed'
}

// 任务类型枚举
export enum TaskType {
    MOVEMENT = 1,    // 移动类任务
    INTERACTION = 2, // 交互类任务
    COLLECTION = 3   // 收集类任务
}

// 任务配置接口
export interface TaskConfig {
    id: number;
    type: TaskType;
    title: string;
    description: string;
    targetPathIndex: number; // 目标路径点
    requiredActions: string[]; // 需要完成的动作
    rewards: string[]; // 奖励
    isOptional: boolean; // 是否为可选任务
}

@ccclass('TaskSystem')
export class TaskSystem extends Component {
    @property({ type: MapManager, tooltip: "地图管理器" })
    mapManager: MapManager | null = null;

    @property({ type: UIManager, tooltip: "UI管理器" })
    uiManager: UIManager | null = null;

    // 任务配置数据
    private taskConfigs: TaskConfig[] = [];
    
    // 当前活跃任务
    private activeTasks: Map<number, TaskConfig> = new Map();
    
    // 已完成任务
    private completedTasks: Set<number> = new Set();
    
    // 事件系统
    public static eventTarget = new EventTarget();

    start() {
        this.initializeTaskConfigs();
        this.registerEvents();
        this.startInitialTasks();
    }

    /**
     * 初始化任务配置
     */
    private initializeTaskConfigs(): void {
        this.taskConfigs = [
            {
                id: 1,
                type: TaskType.MOVEMENT,
                title: "探索新区域",
                description: "移动到第一个路径点，开始你的冒险之旅",
                targetPathIndex: 1,
                requiredActions: ["move_to_point"],
                rewards: ["经验值+10", "解锁新区域"],
                isOptional: false
            },
            {
                id: 2,
                type: TaskType.INTERACTION,
                title: "与环境互动",
                description: "在第二个路径点与环境进行互动",
                targetPathIndex: 2,
                requiredActions: ["interact_with_environment"],
                rewards: ["经验值+15", "获得道具"],
                isOptional: false
            },
            {
                id: 3,
                type: TaskType.COLLECTION,
                title: "收集资源",
                description: "在第三个路径点收集特殊资源",
                targetPathIndex: 3,
                requiredActions: ["collect_resource"],
                rewards: ["经验值+20", "特殊道具"],
                isOptional: false
            }
        ];

        console.log(`初始化了 ${this.taskConfigs.length} 个任务配置`);
    }

    /**
     * 注册事件监听
     */
    private registerEvents(): void {
        // 监听地图事件
        MapManager.eventTarget.on(MapEvent.PLAYER_REACHED_POINT, this.onPlayerReachedPoint, this);
        
        // 监听任务系统内部事件
        TaskSystem.eventTarget.on(TaskEvent.TASK_COMPLETED, this.onTaskCompleted, this);
    }

    /**
     * 开始初始任务
     */
    private startInitialTasks(): void {
        // 开始第一个任务
        this.startTask(1);
    }

    /**
     * 开始任务
     * @param taskId 任务ID
     */
    public startTask(taskId: number): boolean {
        const taskConfig = this.taskConfigs.find(config => config.id === taskId);
        if (!taskConfig) {
            console.error(`任务配置不存在: ${taskId}`);
            return false;
        }

        if (this.activeTasks.has(taskId)) {
            console.log(`任务 ${taskId} 已经在进行中`);
            return false;
        }

        if (this.completedTasks.has(taskId)) {
            console.log(`任务 ${taskId} 已经完成`);
            return false;
        }

        // 添加到活跃任务
        this.activeTasks.set(taskId, taskConfig);
        
        // 触发任务开始事件
        TaskSystem.eventTarget.emit(TaskEvent.TASK_STARTED, taskConfig);
        
        console.log(`开始任务: ${taskConfig.title}`);
        
        // 通知UI更新
        if (this.uiManager) {
            // 这里可以更新UI显示新任务
        }

        return true;
    }

    /**
     * 完成任务
     * @param taskId 任务ID
     */
    public completeTask(taskId: number): boolean {
        const taskConfig = this.activeTasks.get(taskId);
        if (!taskConfig) {
            console.error(`活跃任务不存在: ${taskId}`);
            return false;
        }

        // 从活跃任务中移除
        this.activeTasks.delete(taskId);
        
        // 添加到已完成任务
        this.completedTasks.add(taskId);
        
        // 触发任务完成事件
        TaskSystem.eventTarget.emit(TaskEvent.TASK_COMPLETED, taskConfig);
        
        console.log(`完成任务: ${taskConfig.title}`);
        
        // 给予奖励
        this.giveRewards(taskConfig.rewards);
        
        // 通知UI更新
        if (this.uiManager) {
            this.uiManager.completeTask(taskId);
        }
        
        // 解锁下一个路径点
        if (this.mapManager) {
            this.mapManager.completePathPointTask(taskConfig.targetPathIndex);
        }
        
        // 检查是否开始下一个任务
        this.checkAndStartNextTask(taskId);
        
        // 检查是否所有任务都完成了
        this.checkAllTasksCompleted();

        return true;
    }

    /**
     * 检查并开始下一个任务
     * @param completedTaskId 已完成的任务ID
     */
    private checkAndStartNextTask(completedTaskId: number): void {
        const nextTaskId = completedTaskId + 1;
        const nextTaskConfig = this.taskConfigs.find(config => config.id === nextTaskId);
        
        if (nextTaskConfig && !this.completedTasks.has(nextTaskId)) {
            // 延迟一点时间开始下一个任务，让玩家有时间看到完成提示
            this.scheduleOnce(() => {
                this.startTask(nextTaskId);
            }, 1.0);
        }
    }

    /**
     * 给予奖励
     * @param rewards 奖励列表
     */
    private giveRewards(rewards: string[]): void {
        console.log('获得奖励:');
        rewards.forEach(reward => {
            console.log(`- ${reward}`);
        });
        
        // 这里可以实际给予玩家奖励
        // 比如增加经验值、道具等
    }

    /**
     * 玩家到达路径点事件处理
     * @param pathIndex 路径点索引
     */
    private onPlayerReachedPoint(pathIndex: number): void {
        console.log(`任务系统: 玩家到达路径点 ${pathIndex}`);
        
        // 检查是否有对应的任务需要完成
        for (const [taskId, taskConfig] of this.activeTasks) {
            if (taskConfig.targetPathIndex === pathIndex) {
                // 检查任务是否满足完成条件
                if (this.checkTaskCompletion(taskConfig)) {
                    this.completeTask(taskId);
                }
            }
        }
    }

    /**
     * 检查任务完成条件
     * @param taskConfig 任务配置
     */
    private checkTaskCompletion(taskConfig: TaskConfig): boolean {
        // 这里可以根据任务类型检查不同的完成条件
        switch (taskConfig.type) {
            case TaskType.MOVEMENT:
                // 移动类任务，到达目标点即完成
                return true;
                
            case TaskType.INTERACTION:
                // 交互类任务，需要额外的交互动作
                // 这里简化处理，实际可以检查是否执行了特定交互
                return true;
                
            case TaskType.COLLECTION:
                // 收集类任务，需要收集特定物品
                // 这里简化处理，实际可以检查背包中是否有特定物品
                return true;
                
            default:
                return false;
        }
    }

    /**
     * 任务完成事件处理
     * @param taskConfig 任务配置
     */
    private onTaskCompleted(taskConfig: TaskConfig): void {
        console.log(`任务完成事件: ${taskConfig.title}`);
        // 这里可以添加任务完成后的额外逻辑
    }

    /**
     * 检查是否所有任务都完成了
     */
    private checkAllTasksCompleted(): void {
        const totalTasks = this.taskConfigs.filter(config => !config.isOptional).length;
        const completedMandatoryTasks = this.taskConfigs.filter(config => 
            !config.isOptional && this.completedTasks.has(config.id)
        ).length;
        
        if (completedMandatoryTasks >= totalTasks) {
            TaskSystem.eventTarget.emit(TaskEvent.ALL_TASKS_COMPLETED);
            console.log('恭喜！所有任务都完成了！');
        }
    }

    /**
     * 获取活跃任务列表
     */
    public getActiveTasks(): TaskConfig[] {
        return Array.from(this.activeTasks.values());
    }

    /**
     * 获取已完成任务列表
     */
    public getCompletedTasks(): TaskConfig[] {
        return this.taskConfigs.filter(config => this.completedTasks.has(config.id));
    }

    /**
     * 获取任务配置
     * @param taskId 任务ID
     */
    public getTaskConfig(taskId: number): TaskConfig | undefined {
        return this.taskConfigs.find(config => config.id === taskId);
    }

    /**
     * 检查任务是否完成
     * @param taskId 任务ID
     */
    public isTaskCompleted(taskId: number): boolean {
        return this.completedTasks.has(taskId);
    }

    /**
     * 检查任务是否活跃
     * @param taskId 任务ID
     */
    public isTaskActive(taskId: number): boolean {
        return this.activeTasks.has(taskId);
    }

    /**
     * 强制完成任务（用于调试）
     * @param taskId 任务ID
     */
    public forceCompleteTask(taskId: number): void {
        if (this.activeTasks.has(taskId)) {
            this.completeTask(taskId);
        } else if (!this.completedTasks.has(taskId)) {
            // 如果任务还没开始，先开始再完成
            if (this.startTask(taskId)) {
                this.completeTask(taskId);
            }
        }
    }

    onDestroy() {
        // 清理事件监听
        MapManager.eventTarget.off(MapEvent.PLAYER_REACHED_POINT, this.onPlayerReachedPoint, this);
        TaskSystem.eventTarget.off(TaskEvent.TASK_COMPLETED, this.onTaskCompleted, this);
    }
}
