import { _decorator, Component, Node, find, director } from 'cc';
import { Player } from './Player';
import { MapManager, MapEvent } from './MapManager';
import { UIManager } from './UIManager';
import { TaskSystem, TaskEvent } from './TaskSystem';
import { InteractionSystem } from './InteractionSystem';

const { ccclass, property } = _decorator;

// 游戏状态枚举
export enum GameState {
    LOADING = 'loading',
    PLAYING = 'playing',
    PAUSED = 'paused',
    COMPLETED = 'completed'
}

@ccclass('GameManager')
export class GameManager extends Component {
    @property({ type: Player, tooltip: "玩家角色组件" })
    player: Player | null = null;

    @property({ type: MapManager, tooltip: "地图管理器" })
    mapManager: MapManager | null = null;

    @property({ type: UIManager, tooltip: "UI管理器" })
    uiManager: UIManager | null = null;

    @property({ type: TaskSystem, tooltip: "任务系统" })
    taskSystem: TaskSystem | null = null;

    @property({ type: InteractionSystem, tooltip: "交互系统" })
    interactionSystem: InteractionSystem | null = null;

    // 游戏状态
    private gameState: GameState = GameState.LOADING;
    
    // 游戏数据
    private gameData = {
        playerLevel: 1,
        experience: 0,
        completedTasks: 0,
        totalPlayTime: 0
    };

    // 单例实例
    private static _instance: GameManager | null = null;

    onLoad() {
        // 设置单例
        if (GameManager._instance) {
            this.node.destroy();
            return;
        }
        GameManager._instance = this;
        
        // 保持节点在场景切换时不被销毁
        director.addPersistRootNode(this.node);
    }

    start() {
        this.initializeGame();
    }

    /**
     * 获取游戏管理器单例
     */
    public static getInstance(): GameManager | null {
        return GameManager._instance;
    }

    /**
     * 初始化游戏
     */
    private async initializeGame(): Promise<void> {
        console.log('开始初始化游戏...');
        
        try {
            // 1. 初始化各个系统组件
            await this.initializeComponents();
            
            // 2. 建立系统间的引用关系
            this.setupSystemReferences();
            
            // 3. 注册事件监听
            this.registerEventListeners();
            
            // 4. 加载游戏数据
            this.loadGameData();
            
            // 5. 开始游戏
            this.startGame();
            
            console.log('游戏初始化完成！');
            
        } catch (error) {
            console.error('游戏初始化失败:', error);
        }
    }

    /**
     * 初始化组件
     */
    private async initializeComponents(): Promise<void> {
        const canvas = find('Canvas');
        if (!canvas) {
            throw new Error('找不到Canvas节点');
        }

        // 查找或创建各个系统组件
        if (!this.player) {
            const doudouNode = canvas.getChildByName('doudou');
            if (doudouNode) {
                this.player = doudouNode.getComponent(Player);
                if (!this.player) {
                    this.player = doudouNode.addComponent(Player);
                }
            }
        }

        if (!this.mapManager) {
            this.mapManager = this.getComponent(MapManager);
            if (!this.mapManager) {
                this.mapManager = this.addComponent(MapManager);
            }
        }

        if (!this.uiManager) {
            this.uiManager = this.getComponent(UIManager);
            if (!this.uiManager) {
                this.uiManager = this.addComponent(UIManager);
            }
        }

        if (!this.taskSystem) {
            this.taskSystem = this.getComponent(TaskSystem);
            if (!this.taskSystem) {
                this.taskSystem = this.addComponent(TaskSystem);
            }
        }

        if (!this.interactionSystem) {
            this.interactionSystem = this.getComponent(InteractionSystem);
            if (!this.interactionSystem) {
                this.interactionSystem = this.addComponent(InteractionSystem);
            }
        }
    }

    /**
     * 建立系统间的引用关系
     */
    private setupSystemReferences(): void {
        // 设置地图管理器的玩家引用
        if (this.mapManager && this.player) {
            this.mapManager.player = this.player;
        }

        // 设置任务系统的引用
        if (this.taskSystem) {
            this.taskSystem.mapManager = this.mapManager;
            this.taskSystem.uiManager = this.uiManager;
        }

        // 设置交互系统的引用
        if (this.interactionSystem) {
            this.interactionSystem.mapManager = this.mapManager;
            this.interactionSystem.uiManager = this.uiManager;
            this.interactionSystem.taskSystem = this.taskSystem;
        }

        console.log('系统引用关系建立完成');
    }

    /**
     * 注册事件监听
     */
    private registerEventListeners(): void {
        // 监听地图事件
        MapManager.eventTarget.on(MapEvent.PLAYER_REACHED_POINT, this.onPlayerReachedPoint, this);
        MapManager.eventTarget.on(MapEvent.TARGET_UPDATED, this.onTargetUpdated, this);

        // 监听任务事件
        TaskSystem.eventTarget.on(TaskEvent.TASK_STARTED, this.onTaskStarted, this);
        TaskSystem.eventTarget.on(TaskEvent.TASK_COMPLETED, this.onTaskCompleted, this);
        TaskSystem.eventTarget.on(TaskEvent.ALL_TASKS_COMPLETED, this.onAllTasksCompleted, this);

        console.log('事件监听注册完成');
    }

    /**
     * 加载游戏数据
     */
    private loadGameData(): void {
        // 从本地存储加载游戏数据
        const savedData = this.loadFromLocalStorage();
        if (savedData) {
            this.gameData = { ...this.gameData, ...savedData };
            console.log('加载游戏数据:', this.gameData);
        } else {
            console.log('使用默认游戏数据');
        }
    }

    /**
     * 开始游戏
     */
    private startGame(): void {
        this.gameState = GameState.PLAYING;
        console.log('游戏开始！');
        
        // 显示欢迎消息
        this.showWelcomeMessage();
        
        // 开始计时
        this.startGameTimer();
    }

    /**
     * 显示欢迎消息
     */
    private showWelcomeMessage(): void {
        if (this.uiManager) {
            // 通过UI管理器显示欢迎消息
            console.log('欢迎来到DouDou的生活地图！');
        }
    }

    /**
     * 开始游戏计时
     */
    private startGameTimer(): void {
        // 每秒更新游戏时间
        this.schedule(() => {
            if (this.gameState === GameState.PLAYING) {
                this.gameData.totalPlayTime += 1;
            }
        }, 1.0);
    }

    /**
     * 玩家到达路径点事件处理
     * @param pathIndex 路径点索引
     */
    private onPlayerReachedPoint(pathIndex: number): void {
        console.log(`游戏管理器: 玩家到达路径点 ${pathIndex}`);
        
        // 可以在这里添加全局的路径点到达逻辑
        // 比如播放音效、显示特效等
        
        // 保存游戏进度
        this.saveGameData();
    }

    /**
     * 目标更新事件处理
     * @param targetIndex 目标索引
     */
    private onTargetUpdated(targetIndex: number): void {
        console.log(`游戏管理器: 目标更新到 ${targetIndex}`);
        
        // 保存游戏进度
        this.saveGameData();
    }

    /**
     * 任务开始事件处理
     * @param taskConfig 任务配置
     */
    private onTaskStarted(taskConfig: any): void {
        console.log(`游戏管理器: 任务开始 - ${taskConfig.title}`);
        
        // 可以在这里添加任务开始的全局逻辑
        // 比如播放音效、显示通知等
    }

    /**
     * 任务完成事件处理
     * @param taskConfig 任务配置
     */
    private onTaskCompleted(taskConfig: any): void {
        console.log(`游戏管理器: 任务完成 - ${taskConfig.title}`);
        
        // 更新游戏数据
        this.gameData.completedTasks++;
        this.gameData.experience += 10; // 每完成一个任务获得10经验
        
        // 检查是否升级
        this.checkLevelUp();
        
        // 保存游戏进度
        this.saveGameData();
    }

    /**
     * 所有任务完成事件处理
     */
    private onAllTasksCompleted(): void {
        console.log('游戏管理器: 所有任务完成！');
        
        this.gameState = GameState.COMPLETED;
        
        // 显示游戏完成界面
        this.showGameCompletedScreen();
    }

    /**
     * 检查是否升级
     */
    private checkLevelUp(): void {
        const requiredExp = this.gameData.playerLevel * 50; // 每级需要的经验值
        if (this.gameData.experience >= requiredExp) {
            this.gameData.playerLevel++;
            this.gameData.experience -= requiredExp;
            
            console.log(`恭喜升级！当前等级: ${this.gameData.playerLevel}`);
            
            // 显示升级通知
            if (this.uiManager) {
                // 通过UI管理器显示升级消息
            }
        }
    }

    /**
     * 显示游戏完成界面
     */
    private showGameCompletedScreen(): void {
        console.log('显示游戏完成界面');
        
        // 这里可以显示游戏完成的统计信息
        const stats = {
            level: this.gameData.playerLevel,
            completedTasks: this.gameData.completedTasks,
            playTime: this.formatPlayTime(this.gameData.totalPlayTime)
        };
        
        console.log('游戏统计:', stats);
    }

    /**
     * 格式化游戏时间
     * @param seconds 秒数
     */
    private formatPlayTime(seconds: number): string {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        
        return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    /**
     * 保存游戏数据
     */
    private saveGameData(): void {
        try {
            const dataString = JSON.stringify(this.gameData);
            localStorage.setItem('doudou_game_data', dataString);
            console.log('游戏数据已保存');
        } catch (error) {
            console.error('保存游戏数据失败:', error);
        }
    }

    /**
     * 从本地存储加载数据
     */
    private loadFromLocalStorage(): any {
        try {
            const dataString = localStorage.getItem('doudou_game_data');
            if (dataString) {
                return JSON.parse(dataString);
            }
        } catch (error) {
            console.error('加载游戏数据失败:', error);
        }
        return null;
    }

    /**
     * 暂停游戏
     */
    public pauseGame(): void {
        if (this.gameState === GameState.PLAYING) {
            this.gameState = GameState.PAUSED;
            console.log('游戏已暂停');
        }
    }

    /**
     * 恢复游戏
     */
    public resumeGame(): void {
        if (this.gameState === GameState.PAUSED) {
            this.gameState = GameState.PLAYING;
            console.log('游戏已恢复');
        }
    }

    /**
     * 重置游戏
     */
    public resetGame(): void {
        // 重置游戏数据
        this.gameData = {
            playerLevel: 1,
            experience: 0,
            completedTasks: 0,
            totalPlayTime: 0
        };
        
        // 清除本地存储
        localStorage.removeItem('doudou_game_data');
        
        // 重新加载场景
        director.loadScene(director.getScene()!.name);
        
        console.log('游戏已重置');
    }

    /**
     * 获取游戏状态
     */
    public getGameState(): GameState {
        return this.gameState;
    }

    /**
     * 获取游戏数据
     */
    public getGameData(): any {
        return { ...this.gameData };
    }

    onDestroy() {
        // 清理事件监听
        MapManager.eventTarget.off(MapEvent.PLAYER_REACHED_POINT, this.onPlayerReachedPoint, this);
        MapManager.eventTarget.off(MapEvent.TARGET_UPDATED, this.onTargetUpdated, this);
        TaskSystem.eventTarget.off(TaskEvent.TASK_STARTED, this.onTaskStarted, this);
        TaskSystem.eventTarget.off(TaskEvent.TASK_COMPLETED, this.onTaskCompleted, this);
        TaskSystem.eventTarget.off(TaskEvent.ALL_TASKS_COMPLETED, this.onAllTasksCompleted, this);
        
        // 保存游戏数据
        this.saveGameData();
        
        // 清除单例引用
        GameManager._instance = null;
    }
}
