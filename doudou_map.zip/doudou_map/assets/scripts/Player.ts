import { _decorator, Component, Node, Vec3, tween, Tween } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Player')
export class Player extends Component {
    @property({ type: Node, tooltip: "路径点数组" })
    pathPoints: Node[] = [];
    
    @property({ type: Number, tooltip: "移动速度" })
    moveSpeed: number = 200;
    
    @property({ type: Number, tooltip: "当前路径点索引" })
    currentPathIndex: number = 0;
    
    private isMoving: boolean = false;
    private moveTween: Tween<Node> | null = null;

    start() {
        // 初始化角色位置到第一个路径点
        if (this.pathPoints.length > 0) {
            this.node.setPosition(this.pathPoints[0].getPosition());
        }
    }

    update(deltaTime: number) {
        // 可以在这里添加动画更新逻辑
    }

    /**
     * 移动到指定的路径点
     * @param targetIndex 目标路径点索引
     */
    public moveToPathPoint(targetIndex: number): void {
        if (this.isMoving || targetIndex < 0 || targetIndex >= this.pathPoints.length) {
            return;
        }

        if (targetIndex === this.currentPathIndex) {
            return;
        }

        this.isMoving = true;
        const targetPosition = this.pathPoints[targetIndex].getPosition();
        const currentPosition = this.node.getPosition();
        const distance = Vec3.distance(currentPosition, targetPosition);
        const duration = distance / this.moveSpeed;

        // 停止之前的移动动画
        if (this.moveTween) {
            this.moveTween.stop();
        }

        // 创建移动动画
        this.moveTween = tween(this.node)
            .to(duration, { position: targetPosition })
            .call(() => {
                this.currentPathIndex = targetIndex;
                this.isMoving = false;
                this.onReachPathPoint(targetIndex);
            })
            .start();
    }

    /**
     * 移动到下一个路径点
     */
    public moveToNextPoint(): void {
        const nextIndex = this.currentPathIndex + 1;
        if (nextIndex < this.pathPoints.length) {
            this.moveToPathPoint(nextIndex);
        }
    }

    /**
     * 移动到上一个路径点
     */
    public moveToPreviousPoint(): void {
        const prevIndex = this.currentPathIndex - 1;
        if (prevIndex >= 0) {
            this.moveToPathPoint(prevIndex);
        }
    }

    /**
     * 到达路径点时的回调
     * @param pathIndex 路径点索引
     */
    private onReachPathPoint(pathIndex: number): void {
        console.log(`角色到达路径点: ${pathIndex}`);
        // 这里可以触发相关事件，比如解锁新任务、显示对话等
        // 可以通过事件系统通知其他组件
    }

    /**
     * 获取当前是否在移动
     */
    public getIsMoving(): boolean {
        return this.isMoving;
    }

    /**
     * 获取当前路径点索引
     */
    public getCurrentPathIndex(): number {
        return this.currentPathIndex;
    }

    /**
     * 设置路径点数组
     * @param points 路径点节点数组
     */
    public setPathPoints(points: Node[]): void {
        this.pathPoints = points;
        if (points.length > 0) {
            this.node.setPosition(points[0].getPosition());
            this.currentPathIndex = 0;
        }
    }
}

