import { _decorator, Component, Node, find, Button, Sprite, SpriteFrame, resources, Label } from 'cc';
import { MapManager, MapEvent } from './MapManager';
import { TaskPopupManager, PopupResult } from './TaskPopupManager';

const { ccclass, property } = _decorator;

// 任务状态枚举
export enum TaskState {
    DEFAULT = 0,    // 默认状态
    SELECTED = 1,   // 选中状态
    COMPLETED = 2   // 完成状态
}

// 任务数据接口
export interface TaskData {
    id: number;
    type: number; // 1, 2, 3
    state: TaskState;
    title: string;
    description: string;
}

@ccclass('UIManager')
export class UIManager extends Component {
    @property({ type: Node, tooltip: "聊天框背景板（默认状态）" })
    chatBoxDefault: Node | null = null;

    @property({ type: Node, tooltip: "聊天框背景板（展开状态）" })
    chatBoxExpanded: Node | null = null;

    @property({ type: Node, tooltip: "DOUDOU形象节点" })
    doudouAvatar: Node | null = null;

    @property({ type: Node, tooltip: "输入框节点" })
    inputBox: Node | null = null;

    @property({ type: Node, tooltip: "语音按钮节点" })
    voiceButton: Node | null = null;

    @property({ type: Node, tooltip: "目标栏节点" })
    targetBar: Node | null = null;

    @property({ type: TaskPopupManager, tooltip: "任务弹窗管理器" })
    taskPopupManager: TaskPopupManager | null = null;

    // 任务按钮节点
    private taskButtons: Node[] = [];
    
    // 当前任务数据
    private tasks: TaskData[] = [];
    
    // 当前选中的任务ID
    private selectedTaskId: number = -1;
    
    // 聊天框是否展开
    private isChatExpanded: boolean = false;

    start() {
        this.initializeUI();
        this.setupTaskButtons();
        this.setupInteractions();
        this.registerEvents();
        this.initializeTasks();
    }

    /**
     * 初始化UI元素
     */
    private initializeUI(): void {
        const canvas = find('Canvas');
        if (!canvas) return;

        // 查找UI元素
        if (!this.chatBoxDefault) {
            this.chatBoxDefault = canvas.getChildByName('聊天框背景板（默认状态）');
        }
        
        if (!this.doudouAvatar) {
            this.doudouAvatar = canvas.getChildByName('DOUDOU形象（后续会有点击交互功能 这块逻辑可以之后再写）');
        }
        
        if (!this.inputBox) {
            this.inputBox = canvas.getChildByName('输入框');
        }
        
        if (!this.voiceButton) {
            this.voiceButton = canvas.getChildByName('语音按钮');
        }
        
        if (!this.targetBar) {
            this.targetBar = canvas.getChildByName('目标栏');
        }

        // 查找任务弹窗管理器
        if (!this.taskPopupManager) {
            const popupNode = canvas.getChildByName('TaskPopup');
            if (popupNode) {
                this.taskPopupManager = popupNode.getComponent(TaskPopupManager);
            }
        }

        console.log('UI元素初始化完成');
    }

    /**
     * 设置任务按钮
     */
    private setupTaskButtons(): void {
        const canvas = find('Canvas');
        if (!canvas) return;

        // 查找任务按钮
        const task1 = canvas.getChildByName('任务1（默认）');
        const task2 = canvas.getChildByName('任务2（默认）');
        const task3 = canvas.getChildByName('任务3（默认）');

        if (task1) this.taskButtons.push(task1);
        if (task2) this.taskButtons.push(task2);
        if (task3) this.taskButtons.push(task3);

        console.log(`找到 ${this.taskButtons.length} 个任务按钮`);
    }

    /**
     * 设置交互事件
     */
    private setupInteractions(): void {
        // 设置DOUDOU头像点击事件
        if (this.doudouAvatar) {
            const button = this.doudouAvatar.getComponent(Button);
            if (!button) {
                this.doudouAvatar.addComponent(Button);
            }
            this.doudouAvatar.on(Button.EventType.CLICK, this.onDoudouAvatarClick, this);
        }

        // 设置语音按钮点击事件
        if (this.voiceButton) {
            this.voiceButton.on(Button.EventType.CLICK, this.onVoiceButtonClick, this);
        }

        // 设置任务按钮点击事件
        this.taskButtons.forEach((taskButton, index) => {
            if (taskButton) {
                const button = taskButton.getComponent(Button);
                if (!button) {
                    taskButton.addComponent(Button);
                }
                taskButton.on(Button.EventType.CLICK, () => this.onTaskButtonClick(index + 1), this);
            }
        });
    }

    /**
     * 注册事件监听
     */
    private registerEvents(): void {
        // 监听地图事件
        MapManager.eventTarget.on(MapEvent.PLAYER_REACHED_POINT, this.onPlayerReachedPoint, this);
        MapManager.eventTarget.on(MapEvent.TARGET_UPDATED, this.onTargetUpdated, this);
    }

    /**
     * 初始化任务数据
     */
    private initializeTasks(): void {
        this.tasks = [
            {
                id: 1,
                type: 1,
                state: TaskState.DEFAULT,
                title: "任务1",
                description: "完成第一个挑战"
            },
            {
                id: 2,
                type: 2,
                state: TaskState.DEFAULT,
                title: "任务2", 
                description: "完成第二个挑战"
            },
            {
                id: 3,
                type: 3,
                state: TaskState.DEFAULT,
                title: "任务3",
                description: "完成第三个挑战"
            }
        ];

        this.updateTaskButtonsDisplay();
    }

    /**
     * DOUDOU头像点击处理
     */
    private onDoudouAvatarClick(): void {
        console.log('DOUDOU头像被点击');
        this.toggleChatBox();
    }

    /**
     * 语音按钮点击处理
     */
    private onVoiceButtonClick(): void {
        console.log('语音按钮被点击');
        // 这里可以添加语音录制逻辑
        this.showMessage("语音功能暂未实现");
    }

    /**
     * 任务按钮点击处理
     * @param taskId 任务ID
     */
    private onTaskButtonClick(taskId: number): void {
        console.log(`任务按钮 ${taskId} 被点击`);
        
        // 显示任务弹窗而不是简单的选中
        this.showTaskPopup(taskId);
    }

    /**
     * 切换聊天框状态
     */
    private toggleChatBox(): void {
        this.isChatExpanded = !this.isChatExpanded;
        
        if (this.chatBoxDefault) {
            this.chatBoxDefault.active = !this.isChatExpanded;
        }
        
        // 如果有展开状态的聊天框，可以在这里显示
        console.log(`聊天框${this.isChatExpanded ? '展开' : '收起'}`);
    }

    /**
     * 更新任务按钮显示
     */
    private updateTaskButtonsDisplay(): void {
        this.tasks.forEach((task, index) => {
            const taskButton = this.taskButtons[index];
            if (!taskButton) return;

            const sprite = taskButton.getComponent(Sprite);
            if (!sprite) return;

            // 根据任务状态更新按钮外观
            let spriteName = '';
            if (task.state === TaskState.COMPLETED) {
                spriteName = `任务${task.type}（完成）`;
            } else if (this.selectedTaskId === task.id) {
                spriteName = `任务${task.type}（选中）`;
            } else {
                spriteName = `任务${task.type}（默认）`;
            }

            // 这里可以加载对应的精灵帧
            console.log(`更新任务按钮 ${task.id} 显示: ${spriteName}`);
        });
    }

    /**
     * 显示任务信息
     * @param taskId 任务ID
     */
    private showTaskInfo(taskId: number): void {
        const task = this.tasks.find(t => t.id === taskId);
        if (!task) return;

        console.log(`显示任务信息: ${task.title} - ${task.description}`);
        // 这里可以在聊天框中显示任务详情
        this.showMessage(`当前任务: ${task.title}\n${task.description}`);
    }

    /**
     * 显示消息
     * @param message 消息内容
     */
    private showMessage(message: string): void {
        console.log(`显示消息: ${message}`);
        // 这里可以在聊天框中显示消息
        // 可以创建一个消息气泡或者更新聊天框内容
    }

    /**
     * 显示任务弹窗
     * @param taskId 任务ID
     */
    private showTaskPopup(taskId: number): void {
        if (!this.taskPopupManager) {
            console.error('TaskPopupManager 未找到');
            return;
        }

        // 获取任务配置（需要从TaskSystem获取）
        const gameManager = find('Canvas/GameManager');
        const taskSystem = gameManager?.getComponent('TaskSystem');
        
        if (taskSystem) {
            const taskConfig = taskSystem.getTaskConfig(taskId);
            if (taskConfig) {
                // 显示任务弹窗
                this.taskPopupManager.showTaskPopup(taskConfig, (result: PopupResult, taskId: number) => {
                    this.onTaskPopupResult(result, taskId);
                });
            } else {
                console.error(`找不到任务配置: ${taskId}`);
            }
        } else {
            console.error('TaskSystem 未找到');
        }
    }

    /**
     * 任务弹窗结果处理
     * @param result 弹窗结果
     * @param taskId 任务ID
     */
    private onTaskPopupResult(result: PopupResult, taskId: number): void {
        console.log(`任务弹窗结果: ${result}, 任务ID: ${taskId}`);
        
        switch (result) {
            case PopupResult.COMPLETE:
                this.showMessage(`任务 ${taskId} 已完成！`);
                // 更新任务按钮显示
                this.updateTaskButtonsDisplay();
                break;
                
            case PopupResult.ABANDON:
                this.showMessage(`任务 ${taskId} 已放弃`);
                // 可以在这里添加放弃任务的额外处理
                break;
                
            case PopupResult.CANCEL:
                // 用户取消，不做特殊处理
                break;
        }
    }

    /**
     * 完成任务
     * @param taskId 任务ID
     */
    public completeTask(taskId: number): void {
        const task = this.tasks.find(t => t.id === taskId);
        if (task && task.state !== TaskState.COMPLETED) {
            task.state = TaskState.COMPLETED;
            this.updateTaskButtonsDisplay();
            this.showMessage(`恭喜完成任务: ${task.title}!`);
            console.log(`任务 ${taskId} 已完成`);
        }
    }

    /**
     * 玩家到达路径点事件处理
     * @param pathIndex 路径点索引
     */
    private onPlayerReachedPoint(pathIndex: number): void {
        console.log(`玩家到达路径点 ${pathIndex}`);
        
        // 根据路径点触发相应的任务或对话
        if (pathIndex > 0 && pathIndex <= this.tasks.length) {
            const taskId = pathIndex;
            this.showTaskInfo(taskId);
        }
    }

    /**
     * 目标更新事件处理
     * @param targetIndex 新目标索引
     */
    private onTargetUpdated(targetIndex: number): void {
        console.log(`目标更新到路径点 ${targetIndex}`);
        // 这里可以更新目标栏显示
        this.updateTargetDisplay(targetIndex);
    }

    /**
     * 更新目标显示
     * @param targetIndex 目标索引
     */
    private updateTargetDisplay(targetIndex: number): void {
        if (this.targetBar) {
            // 这里可以更新目标栏的内容
            console.log(`更新目标栏显示: 目标点 ${targetIndex}`);
        }
    }

    /**
     * 获取当前选中的任务ID
     */
    public getSelectedTaskId(): number {
        return this.selectedTaskId;
    }

    /**
     * 获取任务数据
     * @param taskId 任务ID
     */
    public getTaskData(taskId: number): TaskData | undefined {
        return this.tasks.find(t => t.id === taskId);
    }

    onDestroy() {
        // 清理事件监听
        MapManager.eventTarget.off(MapEvent.PLAYER_REACHED_POINT, this.onPlayerReachedPoint, this);
        MapManager.eventTarget.off(MapEvent.TARGET_UPDATED, this.onTargetUpdated, this);
    }
}
