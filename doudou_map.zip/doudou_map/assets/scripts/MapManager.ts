import { _decorator, Component, Node, find, EventTarget } from 'cc';
import { Player } from './Player';

const { ccclass, property } = _decorator;

// 地图事件类型
export enum MapEvent {
    PATH_POINT_CLICKED = 'path_point_clicked',
    PLAYER_REACHED_POINT = 'player_reached_point',
    TARGET_UPDATED = 'target_updated'
}

// 路径点数据接口
export interface PathPointData {
    index: number;
    node: Node;
    isUnlocked: boolean;
    hasTask: boolean;
    taskType?: number; // 1, 2, 3 对应不同任务类型
}

@ccclass('MapManager')
export class MapManager extends Component {
    @property({ type: Player, tooltip: "玩家角色组件" })
    player: Player | null = null;

    @property({ type: Node, tooltip: "目标栏节点" })
    targetBar: Node | null = null;

    // 路径点数据
    private pathPoints: PathPointData[] = [];
    
    // 事件系统
    public static eventTarget = new EventTarget();

    // 当前目标点索引
    private currentTargetIndex: number = 1; // 默认目标是第二个点

    start() {
        this.initializePathPoints();
        this.setupPlayer();
        this.registerEvents();
    }

    /**
     * 初始化路径点
     */
    private initializePathPoints(): void {
        // 查找所有路径点节点
        const canvas = find('Canvas');
        if (!canvas) return;

        const pathPointNodes: Node[] = [];
        
        // 查找主角路径点
        const pathPoint1 = canvas.getChildByName('主角路径');
        const pathPoint2 = canvas.getChildByName('主角路径-001');
        const pathPoint3 = canvas.getChildByName('主角路径-002');
        const pathPoint4 = canvas.getChildByName('主角路径-003');

        if (pathPoint1) pathPointNodes.push(pathPoint1);
        if (pathPoint2) pathPointNodes.push(pathPoint2);
        if (pathPoint3) pathPointNodes.push(pathPoint3);
        if (pathPoint4) pathPointNodes.push(pathPoint4);

        // 初始化路径点数据
        this.pathPoints = pathPointNodes.map((node, index) => ({
            index,
            node,
            isUnlocked: true, // 暂时解锁所有路径点（用于测试）
            hasTask: index > 0, // 除了起始点，其他点都有任务
            taskType: index > 0 ? ((index - 1) % 3) + 1 : undefined
        }));

        console.log(`初始化了 ${this.pathPoints.length} 个路径点`);
        
        // 输出路径点解锁状态（调试用）
        this.pathPoints.forEach((point, index) => {
            console.log(`路径点${index}: ${point.node.name}, 解锁状态: ${point.isUnlocked}`);
        });
    }

    /**
     * 设置玩家
     */
    private setupPlayer(): void {
        if (!this.player) {
            // 尝试从doudou节点获取Player组件
            const canvas = find('Canvas');
            const doudouNode = canvas?.getChildByName('doudou');
            if (doudouNode) {
                this.player = doudouNode.getComponent(Player);
            }
        }

        if (this.player) {
            // 设置路径点到玩家
            const pathNodes = this.pathPoints.map(point => point.node);
            this.player.setPathPoints(pathNodes);
        }
    }

    /**
     * 注册事件监听
     */
    private registerEvents(): void {
        // 监听路径点点击事件
        MapManager.eventTarget.on(MapEvent.PATH_POINT_CLICKED, this.onPathPointClicked, this);
    }

    /**
     * 路径点点击处理
     * @param pathIndex 路径点索引
     */
    private onPathPointClicked(pathIndex: number): void {
        const pathPoint = this.pathPoints[pathIndex];
        if (!pathPoint || !pathPoint.isUnlocked) {
            console.log(`路径点 ${pathIndex} 未解锁或不存在`);
            return;
        }

        if (this.player && !this.player.getIsMoving()) {
            this.player.moveToPathPoint(pathIndex);
            console.log(`移动到路径点 ${pathIndex}`);
        }
    }

    /**
     * 解锁路径点
     * @param pathIndex 路径点索引
     */
    public unlockPathPoint(pathIndex: number): void {
        const pathPoint = this.pathPoints[pathIndex];
        if (pathPoint && !pathPoint.isUnlocked) {
            pathPoint.isUnlocked = true;
            console.log(`解锁路径点 ${pathIndex}`);
            
            // 触发目标更新事件
            MapManager.eventTarget.emit(MapEvent.TARGET_UPDATED, pathIndex);
        }
    }

    /**
     * 完成路径点任务
     * @param pathIndex 路径点索引
     */
    public completePathPointTask(pathIndex: number): void {
        const pathPoint = this.pathPoints[pathIndex];
        if (pathPoint && pathPoint.hasTask) {
            pathPoint.hasTask = false;
            console.log(`完成路径点 ${pathIndex} 的任务`);
            
            // 解锁下一个路径点
            const nextIndex = pathIndex + 1;
            if (nextIndex < this.pathPoints.length) {
                this.unlockPathPoint(nextIndex);
                this.setCurrentTarget(nextIndex);
            }
        }
    }

    /**
     * 设置当前目标
     * @param targetIndex 目标路径点索引
     */
    public setCurrentTarget(targetIndex: number): void {
        if (targetIndex >= 0 && targetIndex < this.pathPoints.length) {
            this.currentTargetIndex = targetIndex;
            this.updateTargetDisplay();
            console.log(`设置新目标: 路径点 ${targetIndex}`);
        }
    }

    /**
     * 更新目标显示
     */
    private updateTargetDisplay(): void {
        // 这里可以更新目标栏的显示内容
        // 根据当前目标点的任务类型显示不同的目标描述
        const targetPoint = this.pathPoints[this.currentTargetIndex];
        if (targetPoint && this.targetBar) {
            // 可以在这里更新目标栏的文本或图标
            console.log(`更新目标显示: 任务类型 ${targetPoint.taskType}`);
        }
    }

    /**
     * 获取路径点数据
     * @param pathIndex 路径点索引
     */
    public getPathPointData(pathIndex: number): PathPointData | null {
        return this.pathPoints[pathIndex] || null;
    }

    /**
     * 获取所有路径点数据
     */
    public getAllPathPoints(): PathPointData[] {
        return [...this.pathPoints];
    }

    /**
     * 获取当前目标索引
     */
    public getCurrentTargetIndex(): number {
        return this.currentTargetIndex;
    }

    /**
     * 检查是否可以移动到指定路径点
     * @param pathIndex 路径点索引
     */
    public canMoveToPathPoint(pathIndex: number): boolean {
        const pathPoint = this.pathPoints[pathIndex];
        return pathPoint ? pathPoint.isUnlocked : false;
    }

    onDestroy() {
        // 清理事件监听
        MapManager.eventTarget.off(MapEvent.PATH_POINT_CLICKED, this.onPathPointClicked, this);
    }
}
